import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.MouseInputListener;
import java.awt.*;
import java.awt.event.*;
import java.util.Arrays;
import java.util.Collections;
import java.util.EventObject;

public class game extends JInternalFrame implements MouseInputListener, ItemListener
{
	//JFrame frame1 = new JFrame();
	JMenuBar menu = new JMenuBar();
	JMenu option = new JMenu("Options");
	JMenuItem reset = new JMenuItem("Reset", KeyEvent.VK_R);
	JPanel panel1 = new JPanel(new GridLayout(3,10));
	JLabel[] label = new JLabel[30];
	String[] options = {"English","French","German"};
	JComboBox language = new JComboBox(options);
	Font fontStyleOne = new Font("Helvetica", Font.BOLD, 20);
	String ranString;
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	String clickedString;
	String[] numbers = {"ONE","TWO", "THREE", "FOUR", "FIVE","SIX", "SEVEN", "EIGHT", "NINE", "TEN",
						"UN", "DEUX", "TROIS", "QUATRE", "SINQ", "SIX", "SEPT", "HUIT", "NEUF", "DIX",
						"EINS", "ZWEI", "DREI", "VIER", "FUNF", "SECHS", "SIEBEN", "AUCHT", "NEUN", "ZEHN"};
	
	//String[] englishNum = {"ONE","TWO","THREE","FOUR","FIVE", "SIX", "SEVEN", "EIGHT", "NINE", "TEN"};	
	//String[] frenchNum = {"UN", "DEUX", "TROIS", "QUATRE", "SINQ", "SIX", "SEPT", "HUIT", "NEUF", "DIX"};
	//String[] germanNum = {"EINS", "ZWEI", "DREI", "VIER", "FUNF", "SECHS", "SIEBEN", "AUCHT", "NEUN", "ZEHN"};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	
	public static void main(String[] args) 
	{
		game playgame = new game();
	}
	
	public game()
	{
		super("Counting Game",true,true,true,true);
		
		setup();
		
		option.add(reset);
		menu.add(option);
		this.add(menu, BorderLayout.NORTH);
		this.add(panel1, BorderLayout.CENTER);
		this.add(language, BorderLayout.SOUTH);
		this.setVisible(true);
		this.setSize(900,300);
		this.setLocation(0,150);
		this.setResizable(false);
	}
	
	public void setup()
	{
		for(int i=0;i<=29;i++)
		{
			label[i] = new JLabel();
			label[i].setBorder(BorderFactory.createLineBorder(Color.BLACK));
			label[i].setFont(fontStyleOne);
			label[i].addMouseListener(this);
			panel1.add(label[i], BorderLayout.NORTH);
		}
		
		language.addItemListener(this);
	}

	public void StringCheck(int languageSelect, String ranString)
	{
		if(language.getSelectedIndex()==0)
		{
		}
		
		else if(language.getSelectedIndex()==1)
		{
			
		}
		
		else if(language.getSelectedIndex()==2)
		{
			
		}
	}
	 
	 public void compare(String ranString, String clickedString)
	 {
		if(clickedString.equals(ranString))
		{
			System.out.println("TRUE");
		}

	 }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////		
	public void mouseMoved(MouseEvent e) 
	{
		
	}

	
	public void itemStateChanged(ItemEvent e) 
	{
		
	}
	
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	public void mouseEntered(MouseEvent e) 
	{
		if(e.getSource() instanceof JLabel)
		{
		int ran = (int) (Math.random()*30);
		ranString= numbers[ran];
		((JLabel)e.getSource()).setText(ranString);
		StringCheck(language.getSelectedIndex(), ranString);
		}
	}

	
	public void mouseExited(MouseEvent e) 
	{
		if(e.getSource() instanceof JLabel)
		{
		((JLabel)e.getSource()).setText("");		
		}
	}

	public void mouseClicked(MouseEvent e)
	{
		if(e.getSource() instanceof JLabel)
		{
		clickedString = ((JLabel)e.getSource()).getText();
		}
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	public void mousePressed(MouseEvent e) 
	{

	}

	public void mouseReleased(MouseEvent e) 
	{
	
	}
	
	public void mouseDragged(MouseEvent e) 
	{

	}

}
