<?php
  
  $json = file_get_contents('../json/ireland_counties.json');
  $counties = json_decode($json);
  $county_names;

  foreach ($counties as $county) {
      $county_names[] = $county->name;
  }

  extract($_GET);
  
  if ($query !== 0) {
  
    $hint = '';
    
    foreach ($county_names as $name) {
      if (strtolower($query) === strtolower(substr($name,0,strlen($query)))) {
        $hint = ($hint === '') ? $name : $hint . ', '.$name;
      }
    }
  }

  echo ($hint === '' ? 'no suggestion' : $hint);
?>