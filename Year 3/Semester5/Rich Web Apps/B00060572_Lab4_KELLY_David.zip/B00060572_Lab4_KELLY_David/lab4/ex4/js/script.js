$(document).ready(function() {

	$('#input_text').on('keyup',function() {

		if ($(this).val() !== '') {
			
			$.ajax({
	            type: "GET",
	            url: "php/gethint.php",
	            data: 'query=' + $(this).val(),
	            success: function(msg){
	                $('#txtHint').empty().append(msg);
	            }
	        });
		} 
		else { $('#txtHint').empty(); }
	});
});