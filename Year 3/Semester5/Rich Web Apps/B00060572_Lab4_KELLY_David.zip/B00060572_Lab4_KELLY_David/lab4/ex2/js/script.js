$(document).ready(function() {

	$.ajax({
			
		dataType: "json",
		url: "json/invoice.json",
		success: function(data){

			$("#invoice").append(data.no);
			$("#date").append(data.date);
			$("#customer").append(data.name + " " + data.address);

			$.each($("tr"),function(index,value) {
				
				if(index > 0) {
					$children = ($(this).children());
					$($children[0]).append(data.products[index - 1].name);
					$($children[1]).append(data.products[index - 1].quantity);
					$($children[2]).append(data.products[index - 1].amount);
				}
			});
		}
	});
});