$(document).ready(function() {
	
	var $preview = $('#preview');
	var _data;

	function buildHtml(data) {
		
		var html = "<div id='preview_canvas'>";
		html += "<h1>" + data.title + "</h1>";
		html += "<h2>" + data.author + "</h2>";
		html += "<img src='" + "images/" + data.image + "'/>";
		html += "<p>" + data.synopsis + "</p>"
		html += "</div>";
		return html;
	}

	function handlerIn() {
		
		var $this = $(this);
		var file_name = $this.attr("alt") + ".json";
		var position = $this.position();
		
		$.ajax({
			
			dataType: "json",
			url: "json/" + file_name,
			success: function(data){

				_data = data;
				$preview.css("top", position.top + $this.height() + 5 + "px").css("left", position.left + $this.width() + 5 + "px");
				$preview.append(buildHtml(data));
			}
		});
	}

	function handlerOut() {
		
		$preview.empty();
	}

	function handlerClick() {
		
		var windowFeatures = "width=500, height=400, scrollbars=yes";
		var popupWindow = window.open("", "", windowFeatures);
		popupWindow.document.write(buildHtml(_data));
	}

	$('.image').on("mouseenter", this, handlerIn).on("mouseleave", this, handlerOut).on("click", this, handlerClick);
});
