$(document).ready(function() {

	$('input').on('click',function(event) {

		event.preventDefault();
		
		if($('#table_canvas').html() === '') {
			
			$.ajax({
	            type: "GET",
	            url: "php/getdata.php",
	            success: function(msg){
	                $('#table_canvas').empty().append(msg);
	            }
	        });
		}
	});
});