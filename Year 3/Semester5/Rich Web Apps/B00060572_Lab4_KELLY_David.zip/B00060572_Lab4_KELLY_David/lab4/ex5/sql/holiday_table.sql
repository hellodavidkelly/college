SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";
--
-- Database: `holidays`
--

-- --------------------------------------------------------

--
-- Table structure for table `holiday`
--

CREATE TABLE IF NOT EXISTS `holiday` (
  `id` int(11) NOT NULL COMMENT 'primary_key',
  `customer_name` varchar(64) NOT NULL,
  `to_departure_airport` varchar(64) NOT NULL,
  `to_departure_datetime` datetime NOT NULL,
  `to_arrival_airport` varchar(64) NOT NULL,
  `to_arrival_datetime` datetime NOT NULL,
  `back_departure_airport` varchar(64) NOT NULL,
  `back_departure_datetime` datetime NOT NULL,
  `back_arrival_airport` varchar(64) NOT NULL,
  `back_arrival_datetime` datetime NOT NULL,
  `hotel_name` varchar(64) NOT NULL,
  `hotel_reservation_start_date` datetime NOT NULL,
  `hotel_reservation_duration` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `holiday`
--

INSERT INTO `holiday` (`id`, `customer_name`, `to_departure_airport`, `to_departure_datetime`, `to_arrival_airport`, `to_arrival_datetime`, `back_departure_airport`, `back_departure_datetime`, `back_arrival_airport`, `back_arrival_datetime`, `hotel_name`, `hotel_reservation_start_date`, `hotel_reservation_duration`) VALUES
(1, 'David Kelly', 'Dublin', '2014-03-04 12:15:00', 'Rome', '2014-03-04 15:25:00', 'Rome', '2014-03-11 16:05:00', 'Dublin', '2014-03-11 17:20:00', 'Radisson', '2014-03-04 11:00:00', 7),
(2, 'Alan Leech', 'Dublin', '2014-03-04 12:15:00', 'Rome', '2014-03-04 15:25:00', 'Rome', '2014-03-11 16:05:00', 'Dublin', '2014-03-11 17:20:00', 'Radisson', '2014-03-04 11:00:00', 7);

