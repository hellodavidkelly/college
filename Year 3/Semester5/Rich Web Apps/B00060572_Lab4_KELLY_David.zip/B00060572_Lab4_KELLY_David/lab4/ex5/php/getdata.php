<?php

	$link = mysql_connect('localhost', 'root', '')
    or die('Could not connect: ' . mysql_error());
    mysql_select_db('holiday') or die('Could not select database');
    $query = 'SELECT * FROM holiday';
	$result = mysql_query($query) or die('Query failed: ' . mysql_error());


	echo "<table>\t<tr>\n";
	echo "\t<th>\n id \t</th>\n";
	echo "\t<th>\n name \t</th>\n";
	echo "\t<th>\n departure airport\t</th>\n";
	echo "\t<th>\n departure date\t</th>\n";
	echo "\t<th>\n arrival airport\t</th>\n";
	echo "\t<th>\n arrival date\t</th>\n";
	echo "\t<th>\n departure airport\t</th>\n";
	echo "\t<th>\n departure time\t</th>\n";
	echo "\t<th>\n arrival airport\t</th>\n";
	echo "\t<th>\n arrival time\t</th>\n";
	echo "\t<th>\n hotel name\t</th>\n";
	echo "\t<th>\n hotel reservation date\t</th>\n";
	echo "\t<th>\n hotel reservation duration\t</th>\n";
	echo "\t</tr>\n";
	while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
    	echo "\t<tr>\n";
    	foreach ($line as $col_value) {
        	echo "\t\t<td>$col_value</td>\n";
    	}
    	echo "\t</tr>\n";
	}
	echo "</table>\n";

	mysql_free_result($result);
    mysql_close($link);
?>
