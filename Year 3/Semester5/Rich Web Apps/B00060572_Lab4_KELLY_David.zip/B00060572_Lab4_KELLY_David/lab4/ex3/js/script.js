$(document).ready(function() {

	var county_names = [];
	var $search_field = $('#search');
	var $popup_div = $('#popup');
	
	$popup_div.css('top', $search_field.position().top + 30)
	$popup_div.css('left', $search_field.position().left);
	$popup_div.css('width', $search_field.css('width'));

	$.ajax({
		dataType : 'json',
		url : 'json/counties.json',
		success : function(data) {
			$(data).each(function(index,value) {
				county_names.push(value.name);
			});
		}
	});

	$search_field.on('keyup',function() {
		
		var input = this.value.toLowerCase();
		var suggestions = $.grep(county_names,function(value,i) {
				return ( value.toLowerCase().indexOf(input) == 0 );
			});
		var html = '';
		
		if (input !== '' && typeof suggestions[0] != 'undefined') {
			$.each(suggestions, function(index, value) {
				html += '<div class="suggestion">' + value + '</div>';
			});
			$popup_div.css('display','block');
		} else {
			$popup_div.css('display','none');
		}

		$popup_div.empty().append(html);
		
		$('.suggestion').on('click', function() {
			$search_field.val(this.textContent);
			$popup_div.css('display','none');

		});
	});
});