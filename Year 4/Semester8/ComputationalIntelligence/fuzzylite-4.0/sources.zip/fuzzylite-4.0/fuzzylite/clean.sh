#!/bin/bash
make -f Makefile clean
rm -rf bin lib build CMakeFiles Makefile CMakeCache.txt cmake_install.cmake

