#!/bin/bash
iconutil -c icns qtfuzzylite.iconset
