import javax.swing.*;
import java.awt.*;

public class GUIThread extends JFrame implements Runnable
{
	String message;
	JLabel label;
	JPanel panel = new JPanel();
	Container c = getContentPane();
	
	
	public static void main(String[] args)
	{
		GUIThread gui = new GUIThread(null);
		gui.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	public GUIThread(String x)
	{
		message=x;
		panel.add(label);
		c.add(panel);
		
		setVisible(true);
		setSize(500,500);
		setLocation(100,100);
	}

	
	public void run() 
	{
		label.setText(message);
		try
		{
			Thread.sleep((long)1000);
		}
		catch(InterruptedException e){}	
	}
}