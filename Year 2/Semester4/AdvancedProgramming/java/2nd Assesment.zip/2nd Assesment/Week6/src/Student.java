
public class Student {
	
	private String name;
	private int age, year;
	
	public Student(String name, int age, int year) {
		this.name = name;
		this.age = age;
		this.year = year;
	}
	
	public String getName() {
		return name;
	}
}
