var searchData=
[
  ['loseenergy',['LoseEnergy',['../class_player.html#acf4db7005ed5daa404e1035a82a8715c',1,'Player']]],
  ['loselife',['LoseLife',['../class_player.html#a383aff8d15a6f7d5af9b313898b6a631',1,'Player']]]
];
