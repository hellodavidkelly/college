var searchData=
[
  ['newfood',['newFood',['../class_food.html#a70fa48f4f8b75a8cc25072ef0d83189b',1,'Food']]]
];
