var searchData=
[
  ['update',['Update',['../class_bridge.html#a47f522a3036991987a36b9f9973451a0',1,'Bridge']]]
];
