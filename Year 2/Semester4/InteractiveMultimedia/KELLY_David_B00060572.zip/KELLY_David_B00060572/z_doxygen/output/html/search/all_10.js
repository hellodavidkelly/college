var searchData=
[
  ['xmovementpersecond',['xMovementPerSecond',['../class_badguy_script.html#a54a3b82f3f8a72ac65c2ef9de4d4bb67',1,'BadguyScript']]]
];
