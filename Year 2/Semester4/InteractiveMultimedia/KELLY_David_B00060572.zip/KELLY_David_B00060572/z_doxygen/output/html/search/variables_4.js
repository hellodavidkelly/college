var searchData=
[
  ['getparts',['getParts',['../class_l2_ship_sensor.html#ab0ce9e2c72170c03532ad0f45ab105c1',1,'L2ShipSensor.getParts()'],['../class_ship_sensor.html#a12336194b71d77cc4d3512fac5817ff7',1,'ShipSensor.getParts()']]]
];
