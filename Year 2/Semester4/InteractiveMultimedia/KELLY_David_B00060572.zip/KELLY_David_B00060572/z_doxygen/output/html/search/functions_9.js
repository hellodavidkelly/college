var searchData=
[
  ['playanimation',['PlayAnimation',['../class_animated_sprite.html#af5f0b329b424f4ea6a646bb9cc4e97d6',1,'AnimatedSprite']]],
  ['positionfood',['positionFood',['../class_food.html#aa665475b1d8fea6986ee3744f934c77a',1,'Food']]]
];
