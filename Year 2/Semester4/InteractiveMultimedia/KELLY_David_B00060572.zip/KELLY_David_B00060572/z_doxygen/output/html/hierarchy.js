var hierarchy =
[
    [ "MonoBehaviour", null, [
      [ "AnimatedSprite", "class_animated_sprite.html", null ],
      [ "Bridge", "class_bridge.html", null ],
      [ "DestroyWhenHit", "class_destroy_when_hit.html", null ],
      [ "Food", "class_food.html", null ],
      [ "GameGUI", "class_game_g_u_i.html", null ],
      [ "Key", "class_key.html", null ],
      [ "Player", "class_player.html", null ],
      [ "RolloverButton", "class_rollover_button.html", null ]
    ] ]
];