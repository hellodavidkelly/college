var class_player =
[
    [ "CheckFullEnergy", "class_player.html#a8fa58536f389817c67966c469f35b0d3", null ],
    [ "CountObjectWithTag", "class_player.html#a0f145328d9356caf4b2a3bbc78f72088", null ],
    [ "GetEnergy", "class_player.html#a5697ef2487a1b0ea4ccf46efd7779ca1", null ],
    [ "GetLives", "class_player.html#a6cdaee0518add8352d3b887d49362af6", null ],
    [ "GetScore", "class_player.html#a95c17035212b2aa3738b66949ea70d6c", null ],
    [ "LoseEnergy", "class_player.html#acf4db7005ed5daa404e1035a82a8715c", null ],
    [ "LoseLife", "class_player.html#a383aff8d15a6f7d5af9b313898b6a631", null ],
    [ "MoveToStartPosition", "class_player.html#ae1df700541ad96580424b950546a4c5f", null ],
    [ "OnTriggerEnter", "class_player.html#a85cfe1f2302df544eeb1ef8084ab9067", null ],
    [ "dieSound", "class_player.html#a592b86fd9c8ee7d3764b17451a05b217", null ],
    [ "energy", "class_player.html#a912f581b56282fd52fb58a3d767e8192", null ],
    [ "energyDownSound", "class_player.html#a96cc2e2dfd4c853f6d91174bf95fcde7", null ],
    [ "energyUpSound", "class_player.html#ab1bb6d406e52a7311ee4e90c577f904e", null ],
    [ "lives", "class_player.html#a4f67cfa1eb59ace44ed72ec7dc2ff6b5", null ],
    [ "score", "class_player.html#a43c38443fc6bbaf003e65a9408a329bf", null ]
];