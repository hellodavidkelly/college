var searchData=
[
  ['badguyscript',['BadguyScript',['../class_badguy_script.html',1,'']]]
];
