var class_game_g_u_i =
[
    [ "DisplayEnergy", "class_game_g_u_i.html#ab5bb66d0d6682838a841a8b3c7313938", null ],
    [ "DisplayFood", "class_game_g_u_i.html#a14527917f7d70ca7863fc41369f87002", null ],
    [ "DisplayLives", "class_game_g_u_i.html#ac3c4ab5a0ccfc69d11a49facecac4c51", null ],
    [ "DisplayScore", "class_game_g_u_i.html#a606f8e772f115a28153ce64b37ebb6c8", null ],
    [ "OnGUI", "class_game_g_u_i.html#a4f8ad6b9ce7ee951f37040fd61db1b69", null ],
    [ "energy0Image", "class_game_g_u_i.html#addaaf5e6428ada3c0bca2e7a8f3c137b", null ],
    [ "energy1Image", "class_game_g_u_i.html#a4649d8f2e869ead2e34a1236f0fe25da", null ],
    [ "energy2Image", "class_game_g_u_i.html#a44d4ccce21ae22bf0ee75909a311b4df", null ],
    [ "lives0Image", "class_game_g_u_i.html#a64ec47396cfa0bda7d7a4d4f992fa348", null ],
    [ "lives1Image", "class_game_g_u_i.html#a324c00977585c504b93562c4042bf9fe", null ],
    [ "lives2Image", "class_game_g_u_i.html#a104fcc5af724fb89316908292e5a46f8", null ],
    [ "player", "class_game_g_u_i.html#aaf11d452941e19af9d99589ec3eede07", null ],
    [ "score0Image", "class_game_g_u_i.html#a9b992cd8fe1ed5570fc81cdbb42f0697", null ],
    [ "score1Image", "class_game_g_u_i.html#a35ea95a9aecbbe5d60859a4147c1e233", null ],
    [ "score2Image", "class_game_g_u_i.html#ae06a2f91bb435f37bb2f877b60b06c78", null ],
    [ "score3Image", "class_game_g_u_i.html#a66e1c2c665e15cc0e5553f40a1f1d1d6", null ]
];