var class_food =
[
    [ "newFood", "class_food.html#a70fa48f4f8b75a8cc25072ef0d83189b", null ],
    [ "positionFood", "class_food.html#aa665475b1d8fea6986ee3744f934c77a", null ],
    [ "foodCount", "class_food.html#abb901fd4d5d3151687c1ea9fd7f64709", null ],
    [ "minFood", "class_food.html#a5bd560d6c7386e3fa786884652528008", null ]
];