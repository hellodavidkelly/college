function purchase()
{
	alert("ORDER CONFIRMATION.\nThe items have been added to your cart and you will be charged upon exiting the store");
}