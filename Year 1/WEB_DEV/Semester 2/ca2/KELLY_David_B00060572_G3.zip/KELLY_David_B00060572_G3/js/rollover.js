function imgOver(id)
{
document.getElementById(id).src="images/hover.jpg";
}
				
function imgOutA(id)
{
document.getElementById(id).src="images/vampire_weekend.jpg";
}
				
function imgOutB(id)
{
document.getElementById(id).src="images/contra.jpg";
}
				
function imgOutC(id)
{
document.getElementById(id).src="images/vampire_weekend_3.jpg";
}

function imgOutD(id)
{
document.getElementById(id).src="images/mgmt.jpg";
}

function imgOutE(id)
{
document.getElementById(id).src="images/mgmt2.jpg";
}