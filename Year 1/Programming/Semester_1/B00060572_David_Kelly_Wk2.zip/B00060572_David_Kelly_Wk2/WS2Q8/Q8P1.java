/********************************************************/
/*			Name: David Kelly							*/
/*			Date: 4/10/12								*/
/*			Program Name: WS2Q8							*/
/*														*/
/*			Description: This is Question 8 from		*/
/*						 worksheet 2 : convertion		*/
/********************************************************/

class Q8P1 {

	public static void main(String[] args){

		double kmph;
			System.out.println("Enter your speed in kmph");
			kmph = Keyboard.readDouble();



			double mph;

			mph = (kmph / 10) * 6;

			System.out.println("Your Result is:");

	System.out.println(mph + "mph");


		}

	}