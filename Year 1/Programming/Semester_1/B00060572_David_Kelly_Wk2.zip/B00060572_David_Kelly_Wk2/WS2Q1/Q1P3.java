
/********************************************************/
/*			Name: David Kelly							*/
/*			Date: 4/10/12								*/
/*			Program Name: WS2Q1.java					*/
/*														*/
/*			Description: This is Question 1 from		*/
/*						 worksheet 2 : part 3			*/
/********************************************************/



class Q1P3{

	public static void main(String[] args)

	{

	//Daclared Variables
	int groups = 100 / 6;
	int remainder = 100 % 6;

	System.out.print("there will be ");
	System.out.print(groups);
	System.out.print(" people in 6 groups, with......");
	System.out.println(remainder);
	System.out.println("..... people remaining without an assigned group.");



	}

}