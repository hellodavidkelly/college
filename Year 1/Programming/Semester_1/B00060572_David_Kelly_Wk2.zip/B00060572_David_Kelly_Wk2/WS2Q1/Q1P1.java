/********************************************************/
/*			Name: David Kelly							*/
/*			Date: 4/10/12								*/
/*			Program Name: WS2Q1.java					*/
/*														*/
/*			Description: This is Question 1 from		*/
/*						 worksheet 2 : part 1			*/
/********************************************************/


class Q1P1{


	public static void main(String[ ] args)

	{

	int age;

	System.out.println("Enter your Age:");
	age = Keyboard.readInt( );

	System.out.println("Your age is" );
	System.out.println(age);

}



}