/********************************************************/
/*			Name: David Kelly							*/
/*			Date: 4/10/12								*/
/*			Program Name: WS2Q1.java					*/
/*														*/
/*			Description: This is Question 1 from		*/
/*						 worksheet 2 : part 2			*/
/********************************************************/


class Q1P2{

	public static void main(String[] args){

	//Declared variables
	int first, second, result;

	System.out.println("Enter first number");
	first = Keyboard.readInt();

	System.out.println("Enter second number");
	second = Keyboard.readInt();

	result = first + second;
	System.out.print("The Result is : ");
	System.out.println(result);
	}


}