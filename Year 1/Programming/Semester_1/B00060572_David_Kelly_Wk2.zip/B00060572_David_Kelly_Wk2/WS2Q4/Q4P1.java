/********************************************************/
/*			Name: David Kelly							*/
/*			Date: 4/10/12								*/
/*			Program Name: WS2Q4							*/
/*														*/
/*			Description: This is Question 4	from		*/
/*						 worksheet 2: double value 	   	*/
/********************************************************/


class Q4P1 {

	public static void main (String[] args) {

		int num;
		num = Keyboard.readInt ();

		int num2;
		num2 = (num * 2);

		System.out.println( num2);

		}


	}