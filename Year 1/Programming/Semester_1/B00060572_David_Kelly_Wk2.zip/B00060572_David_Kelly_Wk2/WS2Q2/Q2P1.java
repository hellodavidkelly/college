/********************************************************/
/*			Name: David Kelly							*/
/*			Date: 4/10/12								*/
/*			Program Name: WS2Q1.java					*/
/*														*/
/*			Description: This is Question 2	from		*/
/*						 worksheet 2: Integers 	    	*/
/********************************************************/


class Q2P1{

	public static void main(String[] args){

	//Declared variables
	int first, second, result;

	System.out.println("Enter first number");
	first = Keyboard.readInt();

	System.out.println("Enter second number");
	second = Keyboard.readInt();

	result = first + second;
	System.out.print("The Result is : ");
	System.out.println(result);
	}


}