/********************************************************/
/*			Name: David Kelly							*/
/*			Date: 4/10/12								*/
/*			Program Name: WS2Q6							*/
/*														*/
/*			Description: This is Question 6	from		*/
/*						 worksheet 2: Reverse    	   	*/
/********************************************************/

class Q6P1{

	public static void main (String[] args) {

		System.out.println("Please enter a letter:");
		char letter1;
		letter1 = Keyboard.readChar ();

		System.out.println("Please enter a second letter:");
		char letter2;
		letter2 = Keyboard.readChar ();


		System.out.println("The reverse is");
		System.out.println(letter2);
		System.out.println(letter1);


		}


	}