//B00060572 David Kelly

	class NameandAddress

	{

		public static void main (String[] args)

		{

			System.out.println("David Kelly");
			System.out.println("Computing Department");
			System.out.println("Institute of Technology Blanchardstown");
			System.out.println("Dublin 15");
			System.out.println("Ireland");


		}// End of main method

	}// End