//B00060572 David Kelly

class Triangletwo

	{

			public static void main(String[] args)

			{
				System.out.println("*");
				System.out.println("**");
				System.out.println("***");
				System.out.println("**D*");
				System.out.println("***K*");
				System.out.println("******");



			}// End of main method

	}// End