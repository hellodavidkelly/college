//B00060572	David Kelly

class Myprogram1

{

	public static void main(String[] args)

	{
		System.out.println("I am learning java"); // Quotation Mark was missing after first bracket

	} //End of main method


}//End