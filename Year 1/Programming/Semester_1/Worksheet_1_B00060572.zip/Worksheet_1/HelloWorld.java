//B00060572 David Kelly

	class HelloWorld

	{
		public static void main (String[]args)

		{
			System.out.println("Hello World!");
			System.out.println("");



		} // End of Main Method


	} // End