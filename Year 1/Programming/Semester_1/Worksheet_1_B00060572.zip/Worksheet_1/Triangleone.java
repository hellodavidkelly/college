//B00060572 David Kelly

class Triangleone

	{
		public static void main(String[] args)

		{
			System.out.println("*");
			System.out.println("**");
			System.out.println("***");
			System.out.println("****");
			System.out.println("*****");
			System.out.println("******");
			System.out.println("");



		}// End of Main Method



	}// END