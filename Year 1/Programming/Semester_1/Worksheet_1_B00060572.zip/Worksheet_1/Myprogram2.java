//B00060572	David Kelly

class Myprogram2

{
	public static void main(String[]args)

	{// main method bracket was missing

		System.out.println("I'm a computing student");// S in system was small on both lines
		System.out.println("I am learning to program in java");// Semi colon was missing at the end

	}// End of method


}// End