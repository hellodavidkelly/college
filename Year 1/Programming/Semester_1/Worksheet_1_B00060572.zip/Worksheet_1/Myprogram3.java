//B00060572	David Kelly

class Myprogram3

{

	public static void main(String[] args)
	{
		System.out.println("I'm a computing student");
		System.out.println("I am learning to program in java");


	} // End of main method


}//End bracket was missing