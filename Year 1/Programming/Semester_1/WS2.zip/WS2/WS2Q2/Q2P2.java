/********************************************************/
/*			Name: David Kelly							*/
/*			Date: 4/10/12								*/
/*			Program Name: WS2Q2.java					*/
/*														*/
/*			Description: This is Question 2 from 		*/
/*						 worksheet 2: Double			*/
/********************************************************/


class Q2P2{


	public static void main(String[] args){

		//Declared variables
		double first, second, result;

		System.out.println("Enter first number");
		first = Keyboard.readDouble();

		System.out.println("Enter second number");
		second = Keyboard.readDouble();

		result = first + second;
		System.out.println("The Result is: ");
		System.out.println(result);
		}


}