/********************************************************/
/*			Name: David Kelly							*/
/*			Date: 4/10/12								*/
/*			Program Name: WS2Q2.java					*/
/*														*/
/*			Description: This is Question 2	from 		*/
/*						 worksheet 2: Char				*/
/********************************************************/


class Q2P3{


	public static void main(String[ ] args)

	{

	char letter;

	System.out.println("Enter your letter:");
	letter = Keyboard.readChar( );

	System.out.println("the letter you entered was:" );
	System.out.println(letter);

}



}