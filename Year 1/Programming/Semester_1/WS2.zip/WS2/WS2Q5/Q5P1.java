/********************************************************/
/*			Name: David Kelly							*/
/*			Date: 4/10/12								*/
/*			Program Name: WS2Q5							*/
/*														*/
/*			Description: This is Question 5	from		*/
/*						 worksheet 2: double value 	   	*/
/********************************************************/

class Q5P1 {

	public static void main (String[] args) {

		System.out.println ("Please enter number:");
		int num;
		num = Keyboard.readInt ();

		System.out.print("this number doubled equals... ");
		int num2;
		num2 = (num * 2);

		System.out.println( num2);

		}


	}